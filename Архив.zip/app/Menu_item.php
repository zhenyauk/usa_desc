<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Menu_item extends Model
{
    protected $table = "menu_items";
}
