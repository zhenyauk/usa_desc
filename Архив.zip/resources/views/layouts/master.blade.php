@include('parts.header')


@section('content')
<h2>Not found</h2>
@show


@include('parts.footer')