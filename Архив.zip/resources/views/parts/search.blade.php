<div class="header-search">
    <a href="#" class="open-modal">Log In</a>
    <form>
        <input type="text" name="" placeholder="Search..." id="">
        <span>
                            <i class="material-icons">search</i>
                        </span>
    </form>
</div>