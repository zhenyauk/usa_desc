<div class="main-subscribe">
    <div class="main-subscribe-form">
        <p class="main-subscribe-form-mob">Get new listings sent everyday!</p>
        <span class="main-subscribe-form-span1">Get now</span>
        <div class="btn">
            <p>
                Nothing selected
            </p>
            <span>
                                    <i class="fas fa-caret-down"></i>
                                </span>
        </div>
        <span class="main-subscribe-form-span2">
                                listings sent to
                            </span>
        <p class="main-subscribe-form-mob2">Get new listings sent everyday!</p>
        <input type="text" placeholder="you@youremail.com">
        <span class="main-subscribe-form-span3">
                                every day!
                            </span>
        <a href="#">
            Subscribe
        </a>
    </div>

    <div class="main-subscribe-cat">

        <div class="main-subscribe-cat-item" data-number="1">
            Design
        </div>
        <div class="main-subscribe-cat-item" data-number="2">
            Coding
        </div>
        <div class="main-subscribe-cat-item" data-number="3">
            Programming
        </div>
        <div class="main-subscribe-cat-item" data-number="4">
            Design
        </div>
        <div class="main-subscribe-cat-item" data-number="5">
            Coding
        </div>
        <div class="main-subscribe-cat-item" data-number="6">
            Programming
        </div>
        <div class="main-subscribe-cat-item" data-number="7">
            Design
        </div>
        <div class="main-subscribe-cat-item" data-number="8">
            Coding
        </div>
        <div class="main-subscribe-cat-item" data-number="9">
            Programming
        </div>
        <div class="main-subscribe-cat-item" data-number="10">
            Design
        </div>
        <div class="main-subscribe-cat-item" data-number="11">
            Coding
        </div>
        <div class="main-subscribe-cat-item" data-number="12">
            Programming
        </div>
    </div>

</div>