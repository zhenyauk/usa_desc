<?php 
    $relationshipAttribute = false;

    if (isset($options->details) && $options->details) {
        $relationshipDetails = json_decode($options->details);
        if (isset($relationshipDetails->attribute)) {
            $relationshipAttribute = $relationshipDetails->attribute;
        }
    }

    $column = $relationshipAttribute ?: $options->label;
?>

<?php if(isset($view) && ($view == 'browse' || $view == 'read')): ?>
    <?php 
        $relationshipData = (isset($data)) ? $data : $dataTypeContent;
        $model = app($options->model);
        $query = $model::find($relationshipData->{$options->column});
    ?>

    <?php if(isset($query)): ?>
        <p><?php echo e($query->{$column}); ?></p>
    <?php else: ?>
        <p>No results</p>
    <?php endif; ?>
<?php else: ?>
    <select class="form-control select2" name="<?php echo e($options->column); ?>">
        <?php
            $model = app($options->model);
            $query = $model::all();
            $relationshipOptions = [];

            if (isset($options->details)) {
                $details = json_decode($options->details);
                $relationshipOptions = isset($details->options) ? $details->options : [];
            }
        ?>

        <?php $__currentLoopData = $relationshipOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key === 'null' ? null : $key); ?>"><?php echo e($value); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relationshipData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($relationshipData->{$options->key}); ?>" <?php if($dataTypeContent->{$options->column} == $relationshipData->{$options->key}): ?><?php echo e('selected="selected"'); ?><?php endif; ?>><?php echo e($relationshipData->{$column}); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
<?php endif; ?>
