<footer class="app-footer">
    <div class="site-footer-right">
        <?php if(setting('admin.copyright')): ?>
            <?php echo setting('admin.copyright'); ?>

        <?php else: ?>
            <?php echo __('admin.theme.footer_copyright'); ?> <a href="http://laraveladminpanel.com" target="_blank">Laravel Admin Panel</a>
            <?php $version = Admin::getVersion(); ?>
            <?php if(!empty($version)): ?>
                - <?php echo e($version); ?>

            <?php endif; ?>
        <?php endif; ?>
    </div>
</footer>
