<?php
    $requestQuery = request()->getQueryString();

    if (isset($parentDataTypeContent)) {
        if (isset($parentDataTypeContent->id) && isset($parentDataType->slug)) {
            $requestQuery = ($requestQuery ? $requestQuery . '&' : '')
                . 'crud_slug=' . $parentDataType->slug
                . '&crud_action=' . request()->route()->getActionMethod()
                . '&crud_id=' . $parentDataTypeContent->id;
        }
    }
?>

<a href="<?php echo e(route('admin.'.$dataType->slug.'.create')); ?>?<?php echo e($requestQuery); ?>" class="btn btn-success btn-add-new">
    <i class="admin-plus"></i> <span><?php echo e(__('admin.generic.add_new')); ?></span>
</a>
