<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">


    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700,700i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,600" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cabin+Sketch:400,700" rel="stylesheet">
    <link rel="stylesheet" href="/assets/ea/easy-autocomplete.min.css">
    <link rel="stylesheet" href="/css/style.css">

    <title><?php if(isset($title)): ?><?php echo e(isset($title) ? $title : ''); ?> | <?php echo e(setting('site.title')); ?><?php else: ?> <?php echo e(setting('site.title')); ?> <?php endif; ?></title>
    <meta name="description" content="<?php echo e(isset($meta_d) ? $meta_d : ''); ?>" />
    <meta name="keywords" content="<?php echo e(isset($meta_k) ? $meta_k : ''); ?>" />
</head>
<body>

<div class="mobile-header">
    <div class="mobile-header-btn">
        <i class="material-icons" id="open-menu">menu</i>
    </div>
    <div class="mobile-header-call">
        <a href="#" class="open-modal">Log In</a>
        <a href="#">Post for Free</a>
    </div>
</div>


<div class="mobile-menu">
    <p>
        <i class="material-icons" id="close-menu">close</i>
    </p>

    <ul>
        <li>
            <a href="#" class="no-click-mob">Categories</a>
            <ul>
                <li>
                    <a href="#">Copywriting</a>
                </li>
                <li>
                    <a href="#">Sales &amp; Marketing</a>
                </li>
                <li>
                    <a href="#">Programming</a>
                </li>
                <li>
                    <a href="#">Business &amp; Management</a>
                </li>
                <li>
                    <a href="#">All Other</a>
                </li>
                <li>
                    <a href="#">Customer Support</a>
                </li>
                <li>
                    <a href="#">Design</a>
                </li>
                <li>
                    <a href="#">DevOps &amp; Sysadmin</a>
                </li>
                <li>
                    <a href="#">Product</a>
                </li>
                <li>
                    <a href="#">Contract</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="#" class="no-click-mob">Resources</a>
            <ul>
                <?php $__currentLoopData = $menu['resource']->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e($item->url); ?>"><?php echo e($item->title); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
        <li>
            <a href="#" class="no-click-mob">Community</a>
            <ul>
                <?php $__currentLoopData = $menu['community']->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e($item->url); ?>"><?php echo e($item->title); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
    </ul>

</div>

<a href="#" id="to-top"><i class="material-icons">keyboard_arrow_up</i></a>

<header>
    <div class="wrapper">
        <div class="header-cnt">

            <div class="header-menu">
                <a href="/">
                    <?php echo e(setting('site.logo_label')); ?>

                </a>

                <div>
                    <ul>
                        <li>
                            <a href="#" class="no-click">Categories</a>
                            <ul>
                                <li>
                                    <a href="#">Copywriting</a>
                                </li>
                                <li>
                                    <a href="#">Sales &amp; Marketing</a>
                                </li>
                                <li>
                                    <a href="#">Programming</a>
                                </li>
                                <li>
                                    <a href="#">Business &amp; Management</a>
                                </li>
                                <li>
                                    <a href="#">All Other</a>
                                </li>
                                <li>
                                    <a href="#">Customer Support</a>
                                </li>
                                <li>
                                    <a href="#">Design</a>
                                </li>
                                <li>
                                    <a href="#">DevOps &amp; Sysadmin</a>
                                </li>
                                <li>
                                    <a href="#">Product</a>
                                </li>
                                <li>
                                    <a href="#">Contract</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="no-click">Resources</a>
                            <ul>
                                <?php $__currentLoopData = $menu['resource']->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e($item->url); ?>"><?php echo e($item->title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="no-click">Community</a>
                            <ul>
                                <?php $__currentLoopData = $menu['community']->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e($item->url); ?>"><?php echo e($item->title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>

            <?php echo $__env->make('parts.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </div>
    </div>
</header>
<!-- Main part open -->
<div id="main-cnt">