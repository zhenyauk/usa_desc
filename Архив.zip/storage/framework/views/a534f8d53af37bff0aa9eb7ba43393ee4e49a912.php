<div class="panel-footer">
    <button type="submit" class="btn btn-primary save"><?php echo e(__('admin.generic.save')); ?></button>
</div>
