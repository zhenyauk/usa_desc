<?php if(isset($options->model) && isset($options->type)): ?>
    <?php if(class_exists($options->model)): ?>
        <?php $relationshipField = $row->field; ?>
        <?php echo $__env->make('admin::formfields.relationship.' . $options->type, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php else: ?>
        cannot make relationship because <?php echo e($options->model); ?> does not exist.
    <?php endif; ?>
<?php else: ?>
    <?php $row =(object) json_decode($row->details,true); ?>
    <?php if(isset($row->model) && isset($row->type)): ?>
        <?php if(class_exists($row->model)): ?>
            <?php $options = $row ?>
            <?php echo $__env->make('admin::formfields.relationship.' . $row->type, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php else: ?>
            cannot make relationship because <?php echo e($row->model); ?> does not exist.
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
