<?php 
    $input = 'input_' . $row->field;

    if( strpos($dataTypeContent->{$row->field}, 'http://') === false && strpos($dataTypeContent->{$row->field}, 'https://') === false) {
        $image = Admin::image( $dataTypeContent->{$row->field} );
    } else {
        $image = $dataTypeContent->{$row->field};
    }
?>
<div id="cropper-<?php echo e($row->field); ?>">
    <input id="<?php echo e($input); ?>" type="hidden" name="<?php echo e($row->field); ?>"
        value="<?php if(isset($dataTypeContent->{$row->field})): ?><?php echo e(old($row->field, $dataTypeContent->{$row->field})); ?><?php elseif(isset($options->default)): ?><?php echo e(old($row->field, $options->default)); ?><?php else: ?><?php echo e(old($row->field)); ?><?php endif; ?>">

    <?php $__currentLoopData = $options->cropper; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photoParams): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <input type="hidden" name="<?php echo e($row->field . '_' . $photoParams->name); ?>"
           value="<?php echo e(old($row->field . '_' . $photoParams->name )); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <button type="button" class="btn btn-success" id="upload-<?php echo e($input); ?>">
        <i class="admin-upload"></i> <?php echo e(__('admin.generic.upload')); ?>

    </button>

    <?php if($image): ?>
        <button id="edit-<?php echo e($input); ?>" type="button" class="btn btn-primary cropper-edit">
            <i class="admin-edit"></i> <?php echo e(__('admin.generic.edit')); ?>

        </button>

        <a type="button" class="btn btn-warning" id="download-<?php echo e($input); ?>" href="<?php echo e($image); ?>" download="<?php echo e($image); ?>" target="_blank">
            <i class="admin-download"></i> <?php echo e(__('admin.generic.download')); ?>

        </a>
    <?php endif; ?>
    <div id="uploadPreview" style="display:none;"></div>
    <?php $__currentLoopData = $options->cropper; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photoParams): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="<?php echo e($photoParams->name); ?> photo-block disabled">
            <div class="cropMain"></div>
            <div class="cropSlider"></div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<style>
    <?php $__currentLoopData = $options->cropper; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photoParams): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $width = ($photoParams->size->width > 300) ? $photoParams->size->width / 2 : $photoParams->size->width;
            $height = ($photoParams->size->width > 300) ? $photoParams->size->height / 2 : $photoParams->size->height;
        ?>

        #cropper-<?php echo e($row->field); ?> .<?php echo e($photoParams->name); ?> .cropMain {
            width: <?php echo e($width); ?>px;
            height: <?php echo e($height); ?>px;
        }
        #cropper-<?php echo e($row->field); ?> .<?php echo e($photoParams->name); ?> .cropSlider {
            width: <?php echo e($width); ?>px;
        }
        <?php if(isset($photoParams->watermark)): ?>
        #cropper-<?php echo e($row->field); ?> .<?php echo e($photoParams->name); ?> .cropMain .crop-container:after {
            background: url(<?php echo e(asset_with_time('/' . $photoParams->watermark)); ?>) no-repeat;
            background-size: <?php echo e($width); ?>px;
        }
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</style>

<?php $__env->startSection('javascript'); ?>
    ##parent-placeholder-b6e13ad53d8ec41b034c49f131c64e99cf25207a##
    <script>
    $(document).ready(function() {
        <?php $__currentLoopData = $options->cropper; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photoParams): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $cropper = $row->field . $photoParams->name;
            ?>

            var <?php echo e($cropper); ?> = new Image.cropper();
            <?php echo e($cropper); ?>.init("#cropper-<?php echo e($row->field); ?> .<?php echo e($photoParams->name); ?>");

            <?php if( old($row->field) ): ?>
                <?php echo e($cropper); ?>.loadImg("<?php echo e(storage_url(old($row->field))); ?>?<?php echo e(time()); ?>");
            <?php elseif( isset($dataTypeContent->{$row->field}) ): ?>
                <?php echo e($cropper); ?>.loadImg("<?php echo e($dataTypeContent->getCroppedPhoto($row->field, $photoParams->name, $photoParams->size->name)); ?>?<?php echo e(time()); ?>");
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

        $("#upload-<?php echo e($input); ?>").dropzone({
            url: "<?php echo e(route('admin.media.upload')); ?>",
            previewsContainer: "#uploadPreview",

            sending: function(file, xhr, formData) {
                formData.append("_token", CSRF_TOKEN);
                formData.append("upload_path", "<?php echo e($dataType->slug.'/'.date('F').date('Y')); ?>");
            },
            success: function(e, res){
                if (res.success){
                    uploadImage(res.path, $("#upload-<?php echo e($input); ?>").parent());
                    toastr.success(res.message, "Sweet Success!");
                } else {
                    toastr.error(res.message, "Whoopsie!");
                }
            },
            error: function(e, res, xhr){
                toastr.error(res, "Whoopsie");
            }
        });

        $('#edit-<?php echo e($input); ?>').click(function(){
            var cropperBlock = $(this).parent();
            var imagePath = "<?php echo e($dataTypeContent->{$row->field}); ?>";

            uploadImage(imagePath, cropperBlock);
        });

        function uploadImage(imagePath, cropperBlock){
            var image;
            cropperBlock.find(".crop-container").remove();
            cropperBlock.find(".noUi-base").remove();

            $('#<?php echo e($input); ?>').val(imagePath);
            cropperBlock.children().removeClass('disabled');

            <?php $__currentLoopData = $options->cropper; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photoParams): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $cropper = $row->field . $photoParams->name;
                ?>

                var <?php echo e($cropper); ?> = new Image.cropper();
                <?php echo e($cropper); ?>.init("#cropper-<?php echo e($row->field); ?> .<?php echo e($photoParams->name); ?>");


                function protocolExists(url) {
                   if (/^(f|ht)tps?:\/\//i.test(url)) {
                      return true;
                   }
                   return false;
                }

                image = imagePath;
                if (!protocolExists(imagePath)) {
                    image = "/<?php echo e(basename(storage_url(''))); ?>/" + imagePath;
                }

                <?php echo e($cropper); ?>.loadImg(image);

                $("button:submit").click(function() {
                    $('input[name=<?php echo e($row->field.'_'.$photoParams->name); ?>]').val(
                        JSON.stringify(coordinates(<?php echo e($cropper); ?>))
                    );
                });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        }
    });
    </script>
<?php $__env->stopSection(); ?>
