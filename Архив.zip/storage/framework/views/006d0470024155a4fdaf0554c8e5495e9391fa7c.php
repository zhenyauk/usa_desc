<?php echo $__env->make('parts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->startSection('content'); ?>
<h2>Not found</h2>
<?php echo $__env->yieldSection(); ?>


<?php echo $__env->make('parts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>