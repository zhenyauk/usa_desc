<?php 
    $relationshipData = (isset($data)) ? $data : $dataTypeContent;

    $model = app($options->model);
    $query = $model::where($options->column, '=', $relationshipData->id)->first();
?>

<?php if(isset($query)): ?>
    <p><?php echo e($query->{$options->label}); ?></p>
<?php else: ?>
    <p>None results</p>
<?php endif; ?>
